package com.example.screendraw

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

enum class Tool { PEN, ERASER, LINE, ARROW, CIRCLE, RECT, MOVE, LASER }

abstract class Item {
    open val movable: Boolean get() = true
    abstract fun draw(c: Canvas)
    abstract fun bounds(): RectF
    abstract fun move(dx: Float, dy: Float)
}

class StrokeItem(val path: Path, val paint: Paint, private val eraser: Boolean) : Item() {
    override val movable: Boolean get() = !eraser
    override fun draw(c: Canvas) { c.drawPath(path, paint) }
    override fun bounds(): RectF {
        val r = RectF(); path.computeBounds(r, true)
        val p = paint.strokeWidth / 2 + 12; r.inset(-p, -p); return r
    }
    override fun move(dx: Float, dy: Float) { path.offset(dx, dy) }
}

class ShapeItem(val type: Tool, var x1: Float, var y1: Float, var x2: Float, var y2: Float, val paint: Paint) : Item() {
    override fun draw(c: Canvas) {
        when (type) {
            Tool.LINE -> c.drawLine(x1, y1, x2, y2, paint)
            Tool.ARROW -> {
                c.drawLine(x1, y1, x2, y2, paint)
                val ang = atan2(y2 - y1, x2 - x1)
                val len = max(30f, paint.strokeWidth * 4)
                for (s in intArrayOf(-1, 1)) {
                    val a = ang + PI.toFloat() + s * 0.5f
                    c.drawLine(x2, y2, x2 + len * cos(a), y2 + len * sin(a), paint)
                }
            }
            Tool.CIRCLE -> c.drawOval(box(), paint)
            Tool.RECT -> c.drawRect(box(), paint)
            else -> {}
        }
    }
    private fun box() = RectF(min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2))
    override fun bounds(): RectF { val r = box(); val p = paint.strokeWidth / 2 + 12; r.inset(-p, -p); return r }
    override fun move(dx: Float, dy: Float) { x1 += dx; x2 += dx; y1 += dy; y2 += dy }
}

class TextItem(val text: String, var x: Float, var y: Float, val paint: Paint) : Item() {
    private val lines get() = text.split("\n")
    override fun draw(c: Canvas) {
        val lh = paint.fontSpacing
        lines.forEachIndexed { i, l -> c.drawText(l, x, y + i * lh, paint) }
    }
    override fun bounds(): RectF {
        val lh = paint.fontSpacing
        val w = lines.maxOf { paint.measureText(it) }
        return RectF(x, y + paint.ascent(), x + w, y + (lines.size - 1) * lh + paint.descent())
    }
    override fun move(dx: Float, dy: Float) { x += dx; y += dy }
}

class ImageItem(val bmp: Bitmap, val rect: RectF) : Item() {
    override fun draw(c: Canvas) { c.drawBitmap(bmp, null, rect, null) }
    override fun bounds() = RectF(rect)
    override fun move(dx: Float, dy: Float) { rect.offset(dx, dy) }
}

class Board {
    val items = ArrayList<Item>()
    val redo = ArrayList<Item>()
    var backup: List<Item>? = null
}

class DrawView(ctx: Context) : View(ctx) {
    var tool = Tool.PEN
    var penColor = Color.RED
    var penSize = 8f
    var opacity = 1f
    var highlighter = false
    var eraserSize = 40f
    var penOnly = false
    var onToolChanged: (() -> Unit)? = null

    var showDrawings = true
        set(v) { field = v; invalidate() }
    var whiteboard = false
        set(v) { field = v; current = null; selected = null; invalidate() }
    var boardColor = Color.WHITE
        set(v) { field = v; invalidate() }

    private val overlayBoard = Board()
    private val whiteBoard = Board()
    private val board: Board get() = if (whiteboard) whiteBoard else overlayBoard

    private var current: Item? = null
    private var selected: Item? = null
    private var resizing = false
    private var lastX = 0f
    private var lastY = 0f

    private class LP(val x: Float, val y: Float, val t: Long)
    private val trail = ArrayList<LP>()
    private var laserDown = false

    private val selPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f; color = 0xFF3D7BFF.toInt()
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3D7BFF.toInt() }
    private val laserPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED; strokeWidth = 10f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val laserDot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED; style = Paint.Style.FILL }

    private fun dp(v: Int) = v * resources.displayMetrics.density

    private fun newPaint(): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        if (tool == Tool.ERASER) {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            strokeWidth = eraserSize
            color = Color.BLACK
        } else {
            color = penColor
            strokeWidth = if (highlighter) penSize * 2.5f else penSize
            alpha = if (highlighter) 100 else (opacity * 255).toInt()
            if (highlighter) strokeCap = Paint.Cap.SQUARE
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!showDrawings) return false
        val tt = e.getToolType(0)
        if (penOnly && tt != MotionEvent.TOOL_TYPE_STYLUS && tt != MotionEvent.TOOL_TYPE_ERASER) return true
        val x = e.x; val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> down(x, y)
            MotionEvent.ACTION_MOVE -> move(x, y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> up()
        }
        invalidate()
        return true
    }

    private fun down(x: Float, y: Float) {
        lastX = x; lastY = y
        when (tool) {
            Tool.PEN, Tool.ERASER -> {
                val p = Path(); p.moveTo(x, y); p.lineTo(x + 0.01f, y)
                current = StrokeItem(p, newPaint(), tool == Tool.ERASER)
            }
            Tool.LINE, Tool.ARROW, Tool.CIRCLE, Tool.RECT -> current = ShapeItem(tool, x, y, x, y, newPaint())
            Tool.MOVE -> {
                resizing = false
                val s = selected
                if (s is ImageItem && hypot(x - s.rect.right, y - s.rect.bottom) < dp(36)) resizing = true
                else selected = board.items.lastOrNull { it.movable && it.bounds().contains(x, y) }
            }
            Tool.LASER -> { laserDown = true; trail.add(LP(x, y, SystemClock.uptimeMillis())) }
        }
    }

    private fun move(x: Float, y: Float) {
        when (tool) {
            Tool.PEN, Tool.ERASER ->
                (current as? StrokeItem)?.path?.quadTo(lastX, lastY, (x + lastX) / 2, (y + lastY) / 2)
            Tool.LINE, Tool.ARROW, Tool.CIRCLE, Tool.RECT ->
                (current as? ShapeItem)?.let { it.x2 = x; it.y2 = y }
            Tool.MOVE -> {
                val s = selected
                if (s != null) {
                    if (resizing && s is ImageItem) {
                        val w = max(dp(60), x - s.rect.left)
                        s.rect.right = s.rect.left + w
                        s.rect.bottom = s.rect.top + w * s.bmp.height / s.bmp.width
                    } else s.move(x - lastX, y - lastY)
                }
            }
            Tool.LASER -> trail.add(LP(x, y, SystemClock.uptimeMillis()))
        }
        lastX = x; lastY = y
    }

    private fun up() {
        laserDown = false
        val c = current
        if (c != null) {
            val tiny = c is ShapeItem && hypot(c.x2 - c.x1, c.y2 - c.y1) < 8f
            if (!tiny) { board.items.add(c); board.redo.clear(); board.backup = null }
        }
        current = null
    }

    override fun onDraw(canvas: Canvas) {
        if (!showDrawings) return
        if (whiteboard) canvas.drawColor(boardColor)
        val sc = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)
        for (i in board.items) i.draw(canvas)
        current?.draw(canvas)
        canvas.restoreToCount(sc)

        val s = selected
        if (tool == Tool.MOVE && s != null && board.items.contains(s)) {
            canvas.drawRect(s.bounds(), selPaint)
            if (s is ImageItem) canvas.drawCircle(s.rect.right, s.rect.bottom, dp(10), handlePaint)
        }
        drawLaser(canvas)
    }

    private fun drawLaser(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        if (laserDown) trail.add(LP(lastX, lastY, now))
        trail.removeAll { now - it.t > 700 }
        if (trail.isEmpty()) return
        for (k in 1 until trail.size) {
            val a = trail[k - 1]; val b = trail[k]
            laserPaint.alpha = (255 * (1f - (now - b.t) / 700f)).toInt().coerceIn(0, 255)
            c.drawLine(a.x, a.y, b.x, b.y, laserPaint)
        }
        val l = trail.last()
        laserDot.alpha = (255 * (1f - (now - l.t) / 700f)).toInt().coerceIn(0, 255)
        c.drawCircle(l.x, l.y, dp(9), laserDot)
        postInvalidateOnAnimation()
    }

    private fun addItem(i: Item) {
        board.items.add(i); board.redo.clear(); board.backup = null
        selected = i; tool = Tool.MOVE
        onToolChanged?.invoke(); invalidate()
    }

    fun addText(t: String) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = penColor; alpha = (opacity * 255).toInt(); textSize = 24f + penSize * 3
        }
        addItem(TextItem(t, width / 2f - 100f, height / 2f, p))
    }

    fun addImage(bmp: Bitmap) {
        val sc = min(width * 0.5f / bmp.width, height * 0.5f / bmp.height)
        val w = bmp.width * sc; val h = bmp.height * sc
        val l = (width - w) / 2; val t = (height - h) / 2
        addItem(ImageItem(bmp, RectF(l, t, l + w, t + h)))
    }

    fun undo() {
        val b = board
        if (b.items.isNotEmpty()) b.redo.add(b.items.removeAt(b.items.lastIndex))
        else b.backup?.let { b.items.addAll(it); b.backup = null }
        selected = null; invalidate()
    }

    fun redo() {
        val b = board
        if (b.redo.isNotEmpty()) b.items.add(b.redo.removeAt(b.redo.lastIndex))
        invalidate()
    }

    fun clearAll() {
        val b = board
        if (b.items.isNotEmpty()) { b.backup = ArrayList(b.items); b.items.clear(); b.redo.clear() }
        selected = null; invalidate()
    }

    fun renderBitmap(): Bitmap {
        val b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        draw(Canvas(b)); return b
    }
}
