# Ekran Çizim (ScreenDraw)

1. Android Studio (Koala veya yeni) ile bu klasörü aç, Gradle sync bitsin.
2. Build > Build APK(s) → app/build/outputs/apk/debug/app-debug.apk
3. Tablete kur, uygulamayı aç, "Başlat"a bas, "Diğer uygulamaların üzerinde göster" iznini ver.
