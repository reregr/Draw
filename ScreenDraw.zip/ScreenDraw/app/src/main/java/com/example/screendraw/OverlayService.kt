package com.example.screendraw

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {

    companion object {
        @Volatile var instance: OverlayService? = null
        const val ACTION_STOP = "com.example.screendraw.STOP"
        private const val CHANNEL = "overlay"
    }

    private lateinit var wm: WindowManager
    private lateinit var draw: DrawView
    private lateinit var drawLp: LP
    private lateinit var menuRoot: LinearLayout
    private lateinit var menuLp: LP
    private lateinit var column: LinearLayout
    private lateinit var panel: FrameLayout

    private var menuOpen = true
    private var panelKind: String? = null
    private var drawingEnabled = true
    private var menuRight = true
    private var boardIdx = 0
    private var textWin: View? = null
    private val boardColors = intArrayOf(Color.WHITE, 0xFF1B1B1B.toInt(), 0xFF1E5E3A.toInt())
    private val buttons = HashMap<String, TextView>()
    private val collapsible = ArrayList<View>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        setupDraw()
        setupMenu()
    }

    override fun onDestroy() {
        instance = null
        runCatching { wm.removeView(draw) }
        runCatching { wm.removeView(menuRoot) }
        textWin?.let { v -> runCatching { wm.removeView(v) } }
        super.onDestroy()
    }

    // ---------- Foreground ----------
    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Ekran Çizim", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Ekran Çizim açık")
            .setContentText("Tamamen kapatmak için bildirime dokun")
            .setContentIntent(stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ---------- Çizim penceresi ----------
    private fun setupDraw() {
        draw = DrawView(this)
        draw.onToolChanged = { updateStates() }
        drawLp = LP(
            LP.MATCH_PARENT, LP.MATCH_PARENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { layoutInDisplayCutoutMode = LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES }
        wm.addView(draw, drawLp)
    }

    private fun applyTouch() {
        val touchable = drawingEnabled && draw.showDrawings
        drawLp.flags = if (touchable) drawLp.flags and LP.FLAG_NOT_TOUCHABLE.inv()
        else drawLp.flags or LP.FLAG_NOT_TOUCHABLE
        // Android 12+: dokunuşun alttaki uygulamaya geçmesi için pencere opaklığı <= 0.8 olmalı
        drawLp.alpha = if (touchable) 1f else 0.79f
        wm.updateViewLayout(draw, drawLp)
        updateStates()
    }

    // ---------- Menü ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int = 12) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun tv(text: String, size: Float = 20f, onClick: (() -> Unit)? = null) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        onClick?.let { c -> setOnClickListener { c() } }
    }

    private fun vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    private fun menuBtn(key: String, label: String, canCollapse: Boolean = true,
                        onClick: () -> Unit, onLong: (() -> Unit)? = null): TextView {
        val b = tv(label, 20f, onClick)
        b.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(dp(3), dp(2), dp(3), dp(2)) }
        onLong?.let { l -> b.setOnLongClickListener { l(); true } }
        buttons[key] = b
        if (canCollapse) collapsible.add(b)
        column.addView(b)
        return b
    }

    private fun setupMenu() {
        column = vbox()
        panel = FrameLayout(this).apply { visibility = View.GONE }
        menuRoot = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = bg(0xE6202124.toInt(), 18)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        menuBtn("menu", "☰", false, { toggleMenu() })
        menuBtn("pen", "✏️", true, { onPen() })
        menuBtn("eraser", "🧽", true, { onEraser() })
        menuBtn("undo", "↶", true, { draw.undo() })
        menuBtn("redo", "↷", true, { draw.redo() })
        menuBtn("clear", "🗑", true, { draw.clearAll() })
        menuBtn("shapes", "🔷", true, { togglePanel("shapes") })
        menuBtn("eye", "👁", true, { draw.showDrawings = !draw.showDrawings; applyTouch() })
        menuBtn("touch", "👆", true, { drawingEnabled = !drawingEnabled; applyTouch() })
        menuBtn("board", "⬜", true, { draw.whiteboard = !draw.whiteboard; updateStates() }, { cycleBoardColor() })
        menuBtn("settings", "⚙️", true, { togglePanel("settings") })
        menuBtn("exit", "⏻", true, { stopSelf() })

        menuLp = LP(
            LP.WRAP_CONTENT, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL or LP.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL; x = dp(6) }
        applySide()
        wm.addView(menuRoot, menuLp)
        updateStates()
    }

    private fun applySide() {
        menuRoot.removeAllViews()
        val pl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        if (menuRight) { menuRoot.addView(panel, pl); menuRoot.addView(column) }
        else { menuRoot.addView(column); menuRoot.addView(panel, pl) }
        menuLp.gravity = (if (menuRight) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        if (menuRoot.isAttachedToWindow) wm.updateViewLayout(menuRoot, menuLp)
    }

    private fun toggleMenu() {
        menuOpen = !menuOpen
        collapsible.forEach { it.visibility = if (menuOpen) View.VISIBLE else View.GONE }
        if (!menuOpen) hidePanel()
    }

    private fun setActive(key: String, on: Boolean) {
        buttons[key]?.background = if (on) bg(0xFF3D7BFF.toInt()) else null
    }

    private fun updateStates() {
        val t = draw.tool
        setActive("pen", t == Tool.PEN)
        setActive("eraser", t == Tool.ERASER)
        setActive("shapes", t != Tool.PEN && t != Tool.ERASER)
        setActive("eye", !draw.showDrawings)
        setActive("touch", !drawingEnabled)
        setActive("board", draw.whiteboard)
    }

    private fun onPen() {
        if (draw.tool == Tool.PEN) togglePanel("pen") else { draw.tool = Tool.PEN; showPanel("pen") }
        updateStates()
    }

    private fun onEraser() {
        if (draw.tool == Tool.ERASER) togglePanel("eraser") else { draw.tool = Tool.ERASER; hidePanel() }
        updateStates()
    }

    private fun cycleBoardColor() {
        boardIdx = (boardIdx + 1) % boardColors.size
        draw.boardColor = boardColors[boardIdx]
    }

    // ---------- Paneller ----------
    private fun showPanel(kind: String) {
        panelKind = kind
        panel.removeAllViews()
        panel.addView(buildPanel(kind))
        panel.visibility = View.VISIBLE
    }

    private fun hidePanel() { panel.visibility = View.GONE; panelKind = null }

    private fun togglePanel(kind: String) {
        if (panelKind == kind && panel.visibility == View.VISIBLE) hidePanel() else showPanel(kind)
    }

    private fun buildPanel(kind: String): View {
        val col = vbox().apply { background = bg(0xFF2B2D31.toInt(), 14); setPadding(dp(10), dp(10), dp(10), dp(10)) }
        col.layoutParams = FrameLayout.LayoutParams(dp(230), ViewGroup.LayoutParams.WRAP_CONTENT)
        when (kind) {
            "pen" -> {
                col.addView(seek("Kalınlık", 1, 60, draw.penSize.toInt()) { draw.penSize = it.toFloat() })
                col.addView(seek("Opaklık %", 10, 100, (draw.opacity * 100).toInt()) { draw.opacity = it / 100f })
                col.addView(toggleRow("🖍 Fosforlu kalem", { draw.highlighter }) { draw.highlighter = it })
                col.addView(colorRow())
            }
            "eraser" -> col.addView(seek("Silgi boyutu", 10, 150, draw.eraserSize.toInt()) { draw.eraserSize = it.toFloat() })
            "shapes" -> {
                val items = listOf(
                    "╱  Düz çizgi" to Tool.LINE, "➚  Ok" to Tool.ARROW, "◯  Daire / elips" to Tool.CIRCLE,
                    "▭  Dikdörtgen" to Tool.RECT, "✋  Taşı / boyutlandır" to Tool.MOVE, "🔴  Lazer işaretçi" to Tool.LASER
                )
                for ((label, tool) in items) col.addView(row(label) { draw.tool = tool; updateStates(); hidePanel() })
                col.addView(row("T  Metin ekle") { hidePanel(); showTextInput() })
                col.addView(row("🖼  Resim ekle (+)") { hidePanel(); pickImage() })
            }
            "settings" -> {
                col.addView(toggleRow("🖊 Sadece kalemle çiz", { draw.penOnly }) { draw.penOnly = it })
                col.addView(row("↔  Menüyü diğer yana al") { menuRight = !menuRight; applySide() })
                col.addView(row("🎨  Tahta rengi değiştir") { cycleBoardColor() })
                col.addView(row("💾  Çizimi PNG kaydet") { savePng() })
            }
        }
        return col
    }

    private fun row(label: String, onClick: () -> Unit) = tv(label, 15f, onClick).apply {
        gravity = Gravity.START or Gravity.CENTER_VERTICAL
        setPadding(dp(6), dp(11), dp(6), dp(11))
    }

    private fun toggleRow(label: String, get: () -> Boolean, set: (Boolean) -> Unit): TextView {
        val t = row(label) {}
        fun refresh() { t.text = "$label: ${if (get()) "Açık ✔" else "Kapalı"}" }
        refresh()
        t.setOnClickListener { set(!get()); refresh() }
        return t
    }

    private fun seek(label: String, lo: Int, hi: Int, value: Int, onChange: (Int) -> Unit): View {
        val box = vbox()
        val t = tv("$label: $value", 13f).apply { gravity = Gravity.START }
        val sb = SeekBar(this).apply {
            this.max = hi - lo
            progress = value - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    t.text = "$label: ${p + lo}"; onChange(p + lo)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(t); box.addView(sb)
        return box
    }

    private fun colorRow(): View {
        val colors = intArrayOf(
            Color.WHITE, Color.BLACK, 0xFFFF3B30.toInt(), 0xFFFF9500.toInt(),
            0xFFFFE600.toInt(), 0xFF34C759.toInt(), 0xFF0A84FF.toInt(), 0xFFBF5AF2.toInt()
        )
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
        for (c in colors) {
            val d = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(c)
                    setStroke(dp(if (c == draw.penColor) 3 else 1), if (c == draw.penColor) 0xFF3D7BFF.toInt() else 0x66FFFFFF)
                }
                layoutParams = LinearLayout.LayoutParams(dp(22), dp(22)).apply { setMargins(dp(2), 0, dp(2), 0) }
                setOnClickListener { draw.penColor = c; showPanel("pen") }
            }
            r.addView(d)
        }
        return r
    }

    // ---------- Metin ----------
    private fun showTextInput() {
        if (textWin != null) return
        val et = EditText(this).apply {
            hint = "Metin yaz"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            minWidth = dp(240); maxLines = 4
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = bg(0xF0202124.toInt(), 16); setPadding(dp(12), dp(8), dp(8), dp(8))
        }
        fun close() { textWin?.let { runCatching { wm.removeView(it) } }; textWin = null }
        val ok = tv("✔", 22f) { val s = et.text.toString(); close(); if (s.isNotBlank()) draw.addText(s) }
        val no = tv("✖", 22f) { close() }
        ok.setPadding(dp(12), 0, dp(8), 0); no.setPadding(dp(8), 0, dp(8), 0)
        box.addView(et); box.addView(ok); box.addView(no)
        val lp = LP(
            LP.WRAP_CONTENT, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(80)
            softInputMode = LP.SOFT_INPUT_ADJUST_PAN or LP.SOFT_INPUT_STATE_VISIBLE
        }
        wm.addView(box, lp)
        textWin = box
        et.requestFocus()
    }

    // ---------- Resim ----------
    private fun pickImage() {
        startActivity(Intent(this, PickImageActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun addImage(b: Bitmap) { draw.addImage(b); updateStates() }

    // ---------- PNG kaydet ----------
    private fun savePng() {
        val bmp = draw.renderBitmap()
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "cizim_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/EkranCizim")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "Kaydedildi: Resimler/EkranCizim", Toast.LENGTH_SHORT).show()
        }
    }
}
